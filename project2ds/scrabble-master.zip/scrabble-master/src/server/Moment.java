package server;

public enum Moment {
    WAITING_ROOM, PLAYING, VOTING, ENDED
}
