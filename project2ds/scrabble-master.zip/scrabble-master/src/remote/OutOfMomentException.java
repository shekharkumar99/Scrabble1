package remote;

public class OutOfMomentException extends Exception {
    public OutOfMomentException(String msg) {
        super(msg);
    }
}
